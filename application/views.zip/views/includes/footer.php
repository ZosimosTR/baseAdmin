<?php 
    $this->load->view('includes/include_script');
 ?>
</body>
</html>