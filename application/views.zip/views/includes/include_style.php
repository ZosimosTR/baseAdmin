<link rel="stylesheet" href="<?php echo base_url('assets/css/normalize.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/font-awesome.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/themify-icons.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/flag-icon.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/cs-skin-elastic.css');?>">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="<?php echo base_url('assets/scss/style.css');?>">
    <link href="<?php echo base_url('assets/css/lib/chosen/chosen.min.css');?>" rel="stylesheet">

    <link href='https://fonts.googleapis.com/css?family=Lato:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script>-->